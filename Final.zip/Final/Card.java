public class Card {

    private String value = "invalid";
    private String suit = "invalid";
    private String id = "XX";

    public Card(String value, String suit){
        this.value = value;
        this.suit = suit;

        char[] strOutArr = new char[2];
        if (value.equals("Two")) strOutArr[0] = '2';
        if (value.equals("Three")) strOutArr[0] = '3';
        if (value.equals("Four")) strOutArr[0] = '4';
        if (value.equals("Five")) strOutArr[0] = '5';
        if (value.equals("Six")) strOutArr[0] = '6';
        if (value.equals("Seven")) strOutArr[0] = '7';
        if (value.equals("Eight")) strOutArr[0] = '8';
        if (value.equals("Nine")) strOutArr[0] = '9';
        if (value.equals("Ten")) strOutArr[0] = '0';
        if (value.equals("Jack")) strOutArr[0] = 'J';
        if (value.equals("Queen")) strOutArr[0] = 'Q';
        if (value.equals("King")) strOutArr[0] = 'K';
        if (value.equals("Ace")) strOutArr[0] = 'A';
        
        if (suit.equals("Spades")) strOutArr[1] = 'S';
        if (suit.equals("Clubs")) strOutArr[1] = 'C';
        if (suit.equals("Hearts")) strOutArr[1] = 'H';
        if (suit.equals("Diamonds")) strOutArr[1] = 'D';

        this.id = new String(strOutArr);
    }

    private boolean check(String items){
            char[] r = items.toCharArray();
            if (r.length != 2) return false;
            if (r[1] == 'S' ||
                r[1] == 'C' ||
                r[1] == 'H' ||
                r[1] == 'D' 
            ){
                if (r[0] == '2' ||
                r[0] == '3' ||
                r[0] == '4' ||
                r[0] == '5' ||
                r[0] == '6' ||
                r[0] == '7' ||
                r[0] == '8' ||
                r[0] == '9' ||
                r[0] == '0' ||
                r[0] == 'J' ||
                r[0] == 'Q' ||
                r[0] == 'K' ||
                r[0] == 'A' 
                ) return true;

            } else return false;
            
            
        
        return true;
    }

    public Card(String id){
        if(check(id)) {
            this.id = id;

            char[] strOutArr = id.toCharArray();
            if (strOutArr[0] == '2') this.value = "Two";
            if (strOutArr[0] == '3') this.value = "Three";
            if (strOutArr[0] == '4') this.value = "Four";
            if (strOutArr[0] == '5') this.value = "Five";
            if (strOutArr[0] == '6') this.value = "Six";
            if (strOutArr[0] == '7') this.value = "Seven";
            if (strOutArr[0] == '8') this.value = "Eight";
            if (strOutArr[0] == '9') this.value = "Nine";
            if (strOutArr[0] == '0') this.value = "Ten";
            if (strOutArr[0] == 'J') this.value = "Jack";
            if (strOutArr[0] == 'Q') this.value = "Queen";
            if (strOutArr[0] == 'K') this.value = "King";
            if (strOutArr[0] == 'A') this.value = "Ace";

            if (strOutArr[1] == 'S') this.suit = "Spades";
            if (strOutArr[1] == 'C') this.suit = "Clubs";
            if (strOutArr[1] == 'H') this.suit = "Hearts";
            if (strOutArr[1] == 'D') this.suit = "Diamonds";
        }
    }

    public String getId(){
        return this.id;
    }

    public String speakCard(){
        return this.value + " of " + this.suit;
    }

    public String getValue(){
        return this.value;
    }

    public int getIntValue(){
        String[] valArr = {"Two","Three","Four","Five"
        ,"Six","Seven","Eight","Nine","Ten","Jack","Queen",
        "King","Ace"};

        for (int i = 0; i < valArr.length; i++){
            if (this.value.equals(valArr[i])) return i+2;
        }
        return 0;
    }

    public void setValue(String value){
        Card card = new Card(value, "Spades");
        if (check(card.getId())){
            this.value = value;
        }
    }
    
    public String getSuit(){
        return this.suit;
    }

    public void setSuit(String suit){
        Card card = new Card("Ace", suit);
        if (check(card.getId())){
            this.suit = suit;
        }
    }
}
