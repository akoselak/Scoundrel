import java.util.Arrays;

public class Game{

    public static void main(String[] args) {

        String preference = args[0];
        Deck deck = new Deck();
        String[] toRemove = {"JD", "JH", "QD", "QH", "KD", "KH", "AD", "AH"};
        deck.remove(toRemove);
        deck.shuffle();
        int monAmt = 0;
        for (int i = 0; i < deck.getLength(); i++){
            Card ec = new Card(deck.getCard(i));
            if (ec.getSuit() == "Spades" || ec.getSuit() == "Clubs") monAmt++;
        }

        Player player = new Player();
        In in = new In();
        Out out = new Out();

        int input = -2;
        int amt = 4;
        boolean canSkip = true;
        String[] clist = new String[amt];
        String[] slist = new String[amt];
        for (int i = 0; i < amt; i++){
            clist[i] = deck.drawCard();
        }

        while (deck.getLength() != 0 || clist.length != 0){
            for (int i = 0; i < amt; i++){
                int x = i + 1;
                if (preference.equals("2")){
                    Card speak = new Card(clist[i]);
                    slist[i] = speak.speakCard();
                    out.print(slist[i] + "[" + x + "] ");
                } else{
                    out.print(clist[i] + "[" + x + "] ");
                }
            }
            out.println();
            for (int i = 0; i < 3; i++){
                out.print("------");
            }
            out.print("-----");
            out.println();
            player.status();
            if(deck.getLength() < 10){
                out.print("           " + deck.getLength());
            } else {
                out.print("            " + deck.getLength()); 
            }
            out.println();

            input = in.readInt();

            if (input == -1 && canSkip){
                deck.add(clist);
                amt = 4;
                canSkip = false;

                if (deck.getLength() < 4) amt = deck.getLength()+1;
                    clist = new String[amt];
                    for (int i = 0; i < amt; i++){
                        clist[i] = deck.drawCard();
                    }
                
                    continue;
            }

            else if (input <= amt && input > 0){
                Card actionCard = new Card(clist[input-1]);
            

                if (actionCard.getSuit() == "Spades" || actionCard.getSuit() == "Clubs"){
                    player.attack(actionCard);
                    monAmt--;
                }
                else if (actionCard.getSuit() == "Hearts"){
                    player.heal(actionCard);
                }
                else player.equip(actionCard);

                Deck miniDeck = new Deck(clist);
                miniDeck.remove(actionCard.getId());
                clist = miniDeck.getStack();
                amt -= 1;
                out.println();

                if (player.getHealth() <= 0 || monAmt == 0) break;

                if (amt == 1){
                    canSkip = true;
                    amt = 4;
                    if (deck.getLength() < 4) amt = deck.getLength()+1;
                    String store = clist[0];
                    clist = new String[amt];
                    clist[0] = store;
                    for (int i = 1; i < amt; i++){
                        clist[i] = deck.drawCard();
                    }
                }
            
            }

            else{
                out.println();
                if (input == -1) out.println("must complete dungeon before you can skip");
                else out.println("Please enter a valid command");
                out.println();
                continue;
            }
        }

        if (player.getHealth() > 0) {
            int score = 0;
            deck.add(clist);
            for (int i = 0; i < deck.getLength(); i++){
                Card sc = new Card(deck.getCard(i));
                if (sc.getSuit() == "Hearts") score += sc.getIntValue();
            }

            out.println("You win!");
            out.println("Score: " + (player.getHealth() + score));
        }

        else {
            int val = 0;
            for (int i = 0; i < deck.getLength(); i++){
                Card sc = new Card(deck.getCard(i));
                if (sc.getSuit() == "Spades" || sc.getSuit() == "Clubs"){
                    if (sc.getIntValue() > 11) val += 11;
                    else val += sc.getIntValue();
                }
            }
            out.println("Game Over!");
            out.println("Score: " + (0-val));
        }
    }
}
