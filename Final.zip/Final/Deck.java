import java.util.Arrays;

public class Deck {

    private String[] stack = {"2S","3S","4S","5S","6S","7S","8S","9S","0S","JS","QS","KS","AS",
    "2C","3C","4C","5C","6C","7C","8C","9C","0C","JC","QC","KC","AC",
    "2H","3H","4H","5H","6H","7H","8H","9H","0H","JH","QH","KH","AH",
    "2D","3D","4D","5D","6D","7D","8D","9D","0D","JD","QD","KD","AD"}; 

    private int len = stack.length;

    public Deck(){}

    public Deck(String[] stack){
        this.stack = stack;
        this.len = stack.length;
    }

    public String[] getStack(){
        return this.stack;
    }

    public String getCard(int i){
        return this.stack[i];
    }

    public String[] getCardRange(int start, int end){
        String[] items = new String[end-start+1];
        for (int i = start; i < end+1; i++){
            items[i - start] = this.stack[i];
        }
        
        return items;
    }

    public int getLength(){
        len = this.stack.length;
        return len;
    }

    public void shuffle(){
        for (int i = 0; i < stack.length; i++) {
            int r = i + (int) (Math.random() * (len - i));
            String temp = this.stack[i];
            this.stack[i] = this.stack[r];
            this.stack[r] = temp;
        }
    }

    private boolean check(String[] items){
        for (int i = 0; i < items.length; i++){
            char[] r = items[i].toCharArray();
            if (r.length != 2) return false;
            if (r[1] == 'S' ||
                r[1] == 'C' ||
                r[1] == 'H' ||
                r[1] == 'D' 
            ){
                if (r[0] == '2' ||
                r[0] == '3' ||
                r[0] == '4' ||
                r[0] == '5' ||
                r[0] == '6' ||
                r[0] == '7' ||
                r[0] == '8' ||
                r[0] == '9' ||
                r[0] == '0' ||
                r[0] == 'J' ||
                r[0] == 'Q' ||
                r[0] == 'K' ||
                r[0] == 'A' 
                ) continue;

            } else return false;
            
            
        }
        return true;
    }

    private boolean check(String items){
        char[] r = items.toCharArray();
        if (r.length != 2) return false;
        if (r[1] == 'S' ||
            r[1] == 'C' ||
            r[1] == 'H' ||
            r[1] == 'D' 
        ){
            if (r[0] == '2' ||
            r[0] == '3' ||
            r[0] == '4' ||
            r[0] == '5' ||
            r[0] == '6' ||
            r[0] == '7' ||
            r[0] == '8' ||
            r[0] == '9' ||
            r[0] == '0' ||
            r[0] == 'J' ||
            r[0] == 'Q' ||
            r[0] == 'K' ||
            r[0] == 'A' 
            ) return true;

        } else return false;
        
        
    
    return true;
}

    public void remove(String[] items){
        String[] newStack = new String[len - items.length];
        if (check(items)){
            int r = 0;
            for (int i = 0; i < len; i++){
                boolean canAdd = true;
                for (int j = 0; j < items.length; j++){
                    if (this.stack[i].equals(items[j])){
                        canAdd = false;
                        break;
                    }
                }

                if (canAdd){
                    newStack[r] = this.stack[i];
                    r++;
                }

            }

            this.stack = Arrays.copyOf(newStack, newStack.length);
            this.len = this.stack.length;
        }
        
    }

    public void remove(String items){
        String[] newStack = new String[len - 1];
        if (check(items)){
            int r = 0;
            for (int i = 0; i < len; i++){
                boolean canAdd = true;
                if (this.stack[i].equals(items)){
                    canAdd = false;
                }

                if (canAdd){
                    newStack[r] = this.stack[i];
                    r++;
                }

            }

            this.stack = Arrays.copyOf(newStack, newStack.length);
            this.len = this.stack.length;
        }
        
    }

    public void add(String[] items){
        if(check(items)){
            String[] newStack = new String[len + items.length];
            int r = 0;
            for (int i = 0; i < len; i++){
                newStack[r] = this.stack[i];
                r++;
            }

            for (int i = 0; i < items.length; i++){
                newStack[r] = items[i];
                r++;
            }

            this.stack = Arrays.copyOf(newStack, newStack.length);
            this.len = this.stack.length;
        }
    }

    public String drawCard(){
        String card = this.stack[0];
        remove(card);
        return card;
    }

    public void moveBack(int amt){
        String storage = "XX";
        this.stack = Arrays.copyOf(this.stack, len + amt);
        for (int i = 0; i < amt; i++){
            storage = this.stack[i];
            this.stack[len + i] = storage;       
        }
        this.stack = Arrays.copyOfRange(this.stack, amt, len + amt);
    }
}