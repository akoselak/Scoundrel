public class Player{

    private int health;
    private int power;

    public Player(){
        this.health = 20;
        this.power = 0;
    }

    public Player(int health, int power){
        this.health = health;
        this.power = power;
    }

    public int getHealth(){
        return this.health;
    }

    public void setHealth(int health){
        if (health > 20) this.health = 20;
        if (health < 0) this.health = 0;
        else this.health = health;
    }

    public int getPower(){
        return this.power;
    }

    public void setPow(Card card){
        char[] id = card.getId().toCharArray();
        char num = id[0];
        int pow = 0;

        if (num == '0' ||
            num == 'J' ||
            num == 'Q' ||
            num == 'K'
        ) {pow = 10;}
        if (num == 'A') {pow = 1;}
        else pow = Character.getNumericValue(num);
        
        this.power = pow;
    }

    public void status(){
        System.out.println("Health: " + this.health);
        System.out.print("Weapon: " + this.power);
    }

    private int createItem(Card card){
        String[] posVal = {"Two","Three","Four","Five"
        ,"Six","Seven","Eight","Nine","Ten","Jack","Queen",
        "King","Ace"};
        int item = 0;
        for (int i = 0; i < posVal.length; i++){
            if (card.getValue().equals(posVal[i])) item = i+2;
        }
        if (item > 10) item = 10;
        return item;
    }

    public void heal(Card card){
        int heal = createItem(card);
        if (this.health + heal > 20) {this.health = 20;}
        else if (this.health + heal < 0) {this.health = 0;}
        else this.health += heal;
    }

    public void equip(Card card){
        this.power = createItem(card);
    }

    private int createEnemy(Card card){
        char[] id = card.getId().toCharArray();
        char num = id[0];


        // if (num == '0' ||
        //     num == 'J' ||
        //     num == 'Q' ||
        //     num == 'K'
        // ) return 10;
        switch (num){
            case('0'): return 10;
            case('J'): return 11;
            case('Q'): return 11;
            case('K'): return 11;
            case('A'): return 11;
        }
        
        return Character.getNumericValue(num);

    }

    public void attack(Card card){
        int enemy = createEnemy(card);
        if (this.power < enemy) {
            this.health += (this.power - enemy);
            this.power = 0;
        }

        else this.power = enemy;

    }
}